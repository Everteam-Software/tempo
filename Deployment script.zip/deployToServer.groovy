/************************************************************************

  This script updates Intalio|BPP configuration and deployment files
  when you change your application server's HTTP or HTTPS port

  To run this script,

  On Windows:

      % cd \path\to\bpms\var\config
      C:\path\to\bpms\extras> groovy.bat change_http_port.groovy

  On Linux, Solaris and other Unix-like:

      % cd /path/to/bpms/extras
      % ./groovy.sh change_http_port.groovy

************************************************************************/ 
DEFAULT_PORT= "HTTP"
DEFAULT_IP="172.17.128.120"
DEFAULT_HTTP_PORT=9080
DEFAULT_HTTPS_PORT=8443
DEFAULT_DATABASE_NAME="tap"
DEFAULT_DATABASE_USER="root"
DEFAULT_DATABASE_PASSWORD="appear"
DEFAULT_DATABASE_URL="jdbc:mysql://localhost:3306/tap"
DEFAULT_ORIGINAL_TAMANAGEMENT_GI_PACKAGE_JS="C:\\Intalio\\Workspaces\\DesignerWSs\\Customers\\SITA\\SITA\\forms\\custom\\TAmanagement\\Packages.js"
DEFAULT_TO_REPLACE_TAMANAGEMENT_GI_PACKAGE_JS="build\\forms\\TAmanagement.gi\\IntalioInternal\\Packages.js"

HOST_IP=DEFAULT_IP
PORT=DEFAULT_HTTP_PORT
DATABASE_NAME=DEFAULT_DATABASE_NAME
DATABASE_USER=DEFAULT_DATABASE_USER
DATABASE_PASSWORD=DEFAULT_DATABASE_PASSWORD
HTTPS=false
ORIGINAL_TAMANAGEMENT_GI_PACKAGE_JS=DEFAULT_ORIGINAL_TAMANAGEMENT_GI_PACKAGE_JS
TO_REPLACE_TAMANAGEMENT_GI_PACKAGE_JS=DEFAULT_TO_REPLACE_TAMANAGEMENT_GI_PACKAGE_JS


println()
println "This script updatesSITA configuration and deployment files"
println "this script changes HTTP or HTTPS port, IP of the server host, database and its credentials, switches some files and deploys"
println()

console = new BufferedReader(new InputStreamReader(System.in))
/*
//Uncomment those lines if you want to set up the parameters from the command line
while (true) {
    print("Do you want to use HTTP or HTTPS? [default:"+DEFAULT_PORT+" ] ")
    answer = console.readLine()
    if (answer.trim().equals("")) { answer = DEFAULT_PORT; break }
    if (answer.equalsIgnoreCase("http") || answer.equalsIgnoreCase("https")) break
    println("Invalid answer: ${answer}")
}
HTTPS = answer.equalsIgnoreCase("https")

while (true) {
    print("What is the host server IP [default: "+DEFAULT_IP+"]")
    answer = console.readLine()
    if (answer.trim().equals("")) { answer = DEFAULT_IP; break }
}
HOST_IP = answer

PORT = HTTPS ? DEFAULT_HTTPS_PORT : DEFAULT_HTTP_PORT
while (true) {
    print("New ${HTTPS ? "HTTPS" : "HTTP"} port number? [default: ${PORT}] ")
    answer = console.readLine()
    if (answer.trim().equals("")) break 
    try {
        PORT = Integer.parseInt(answer)
        break
    } catch (Exception e) {
        println("Invalid port number: ${answer}")
    }
}
*/
BASE="."
while (true) {
    print("Path to designer's unziped deployment archive ")
    answer = console.readLine()
break
}
BASE = answer

println()
print("Press [ENTER] to start.")
console.readLine()

def find(... args) {
  urls = new URL[1]
  urls[0] = new URL("file:./libs/FindReplace.jar")
  loader = new java.net.URLClassLoader(urls, this.class.getClassLoader())
  find = Class.forName("FindReplace", true, loader).newInstance()
  find.main(args)
}



def replaceURL_WS(String baseURL) {
    EXTENSIONS = [ "*.pipa", "*.properties", "*.xml", "*.bpel", "*.wsdl" ]
    URL_PREFIX = "(https?://)([^:/]*)(:\\d*)"
    REPLACE    = (String) "${HTTPS ? "https" : "http"}://${HOST_IP}:${PORT}\$4"
    EXTENSIONS.each { ext -> 
        find("-r", BASE, "-replaceRegex", URL_PREFIX+"("+baseURL+")", REPLACE, ext)
    }
}

def replaceURL_JMS(String port) {
    EXTENSIONS = [ "*.pipa", "*.properties", "*.xml", "*.bpel", "*.wsdl" ]
    URL_PREFIX = "(tcp://)([^:/]*)(:"+port+")"
    REPLACE    = (String) "tcp://${HOST_IP}\$3"
    EXTENSIONS.each { ext -> 
        find("-r", BASE, "-replaceRegex", URL_PREFIX, REPLACE, ext)
    }
}
def replaceXMLProperty(String property,String replacement,List EXTENSIONS) {
    
    PROPERTY = "(<[^>/]*"+property+"[^>]*>)(.*)(</[^>/]*"+property+"[^>]*>)"
    REPLACE    = (String) "\$1"+replacement+"\$3"
    EXTENSIONS.each { ext -> 
        find("-r", BASE, "-replaceRegex", PROPERTY, REPLACE, ext)
    }
}

def replaceDB_properties() {
EXTENSIONS=["*.sql.xml" ]
replaceXMLProperty("databaseName",DEFAULT_DATABASE_NAME,EXTENSIONS)
replaceXMLProperty("userName",DEFAULT_DATABASE_USER,EXTENSIONS)
replaceXMLProperty("password",DEFAULT_DATABASE_PASSWORD,EXTENSIONS)
replaceXMLProperty("databaseUrl",DEFAULT_DATABASE_URL,EXTENSIONS)
}

def replaceFORM_URL_BPEL(String baseURL) {
    EXTENSIONS = [ "*.bpel" ]
    URL_PREFIX = "(https?://)([^:/]*)(:\\d*)"
    REPLACE    = (String) "${HTTPS ? "https" : "http"}://${HOST_IP}:${PORT}\$4"
    EXTENSIONS.each { ext -> 
        find("-r", BASE, "-replaceRegex", URL_PREFIX+"("+baseURL+")", REPLACE, ext)
    }
}

///replacing SOAP and WS hosts
replaceURL_WS "/ode/processes/SITA/database/getAllAvis"
replaceURL_WS "/ode/processes/SITA/database/getAllCoord"
replaceURL_WS "/ode/processes/SITA/database/getAllMechs"
replaceURL_WS "/ode/processes/SITA/database/countExistingTAs" 
replaceURL_WS "/ode/processes/SITA/process/NotifToAMI/NotifToAMIprocess/NotifInterface"
replaceURL_WS "/axis2/services/SITAservice"
replaceURL_WS "/ode/processes/SITA/process/TAlistToAMI/TAlistExportProcess/TAinterface"
replaceURL_WS "/axis2/services/TaskManagementServices"
replaceURL_WS "/fds/workflow/xform"
replaceURL_WS "/ode/processes/completeTask"
replaceURL_WS "/ode/processes/TMP"
replaceURL_WS "/axis2/services/TokenService"
/////////replacing JMS hosts 
replaceURL_JMS "61616"

replaceDB_properties()

replaceFORM_URL_BPEL("/gi/apppath/SITA/forms/TAmanagement.gi/IntalioInternal/ServerLaunch.html")
println "Replacing file Package.js for the form TAManagement.gi "
while (true) {
println "Replacing file Package.js for the form TAManagement.gi [default: "+ORIGINAL_TAMANAGEMENT_GI_PACKAGE_JS+"]"
    answer = console.readLine()
    if (answer.trim().equals("")) break 
    try {
        TO_REPLACE_TAMANAGEMENT_GI_PACKAGE_JS = Integer.parseInt(answer)
        break
    } catch (Exception e) {
        println("Invalid port number: ${answer}")
    }
}
def replaceFile(String original,String replacement){
f=new File(BASE+"/forms.gi/forms/TAmanagement.gi/IntalioInternal/Packages.js")
/*f.delete()
f=new File(BASE+"/forms.gi/forms/TAmanagement.gi/IntalioInternal/Packages.js")*/
f << new File(original).asWritable() 
}
replaceFile(ORIGINAL_TAMANAGEMENT_GI_PACKAGE_JS,BASE+"/"+TO_REPLACE_TAMANAGEMENT_GI_PACKAGE_JS)
/*SUBMISSIONS = [ "console-entry", "generate-form", "invoke-service", "load-wsdl" ]
SUBMISSIONS.each { submission ->
  find("-replaceRegex", "name=\"endpoint\">https?:", (String) "name=\"endpoint\">${HTTPS ? "https" : "http"}:", submission, (String) "webapps/wsi/WEB-INF/wsi/models/${submission}.xpl")
}*/