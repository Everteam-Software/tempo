Place your Dynamic Properties (jss) documents in this folder.
